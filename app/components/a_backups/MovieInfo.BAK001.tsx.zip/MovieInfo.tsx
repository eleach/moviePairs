import React, { useState } from 'react';

export function MovieInfo({ myId, myName }) {
  // console.log('myId: ', myId);
  // console.log('myName: ', myName);

  const [expanded, setExpanded] = useState(false);

  return (
    <div>
      <h1>Info</h1>
      myId: {myId}
      <br />
      myName: {myName}
    </div>
  );
}
