import React, { useState } from 'react';
import { Link } from '@remix-run/react';
import { useFetcher } from '@remix-run/react';

export function MovieInfo({ myId, myName }) {
  // console.log('myId: ', myId);
  // console.log('myName: ', myName);

  const [actorsArr, setActorsArr] = useState([]);

  const fetcher = useFetcher();

  let data = '';

  async function handleClick(e) {
    let data = await fetcher.load('/a');
    console.log('e: ', e);
    console.log('data: ', fetcher.data);
  }

  return (
    <div>
      <h1>Info</h1>
      myId: {myId}
      <br />
      <button type="button" onClick={() => handleClick(22)}>
        DOWNNNN
      </button>
      <br />
      {fetcher.data && <div>data: {fetcher.data.arr}</div>}
    </div>
  );
}
