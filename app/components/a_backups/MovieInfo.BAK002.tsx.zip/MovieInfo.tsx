import React, { useState } from 'react';
import { Link } from '@remix-run/react';
import { useFetcher } from '@remix-run/react';

export function MovieInfo({ myId, myName }) {
  // console.log('myId: ', myId);
  // console.log('myName: ', myName);

  const [actorsArr, setActorsArr] = useState([]);

  const myActors = useFetcher<typeof resourceLoader>();

  async function getActors() {
    const actors = await myActors('/resource/getActorsByMovie', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ myId }),
    });

    console.log('actors: ', actors);

    setActorsArr(() => actors);
  }

  // TODO: move this to resource route

  /*
  let getActorList = async () => {
    ////////////////////
    // BEGIN GET LIST OF ACTORS FROM MOVIEID

    console.log('in getActorList');
    const actors = await prisma.$queryRaw`SELECT actor FROM "assoc" WHERE "assoc"."movie" =  112`;

    console.log('actors: ', actors);

    const actorIdArray = actors.map((r) => r.actor);

    console.log('actorIdArray: ', actorIdArray);

    const myNames = await prisma.$queryRaw`SELECT name FROM "actors" WHERE "actors"."myId" =  ANY(${actorIdArray})`;

    console.log('myNames: ', myNames);
    // END GET LIST OF ACTORS FROM MOVIEID
    ////////////////////
    setActorList(() => myNames);

  };

 */

  return (
    <div>
      <h1>Info</h1>
      myId: {myId}
      <br />
      <Link to="./resource/getActorsByMovie.tsx" reloadDocument>
        DOWNNNN
      </Link>
      <br />
    </div>
  );
}
