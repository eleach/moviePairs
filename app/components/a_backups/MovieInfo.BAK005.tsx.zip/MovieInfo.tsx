import React, { useState } from 'react';
import { Link } from '@remix-run/react';
import { PrefetchPageLinks, useFetcher } from '@remix-run/react';

export function MovieInfo({ myId, myName }) {
  // console.log('myId: ', myId);
  // console.log('myName: ', myName);

  const [actorsArr, setActorsArr] = useState([]);

  const fetcher = useFetcher();

  function handleClick({
    
  }) {
    fetcher.load('/resource?id=22');

  })

  return (
    <div>
      <h1>Info</h1>
      myId: {myId}
      <br />
      <PrefetchPageLinks page="/resource" />
      <button type="button" onClick={() => fetcher.load('/resource?id=22')}>
        Load Data
      </button>
      {fetcher.data && <DisplayData data={fetcher.data} />}
      <br />
    </div>
  );
}

function DisplayData({ data }) {
  console.log('data: ', data);
  return <p>{data.message}</p>;
}
