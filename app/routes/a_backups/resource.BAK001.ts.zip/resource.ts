import { json } from '@remix-run/node';

export async function loader({ request }) {
  const url = new URL(request.url);
  const id = url.searchParams.get('id');
  // await new Promise((resolve) => setTimeout(resolve, 5));
  return json({ message: `Hello ${id}` });
}
