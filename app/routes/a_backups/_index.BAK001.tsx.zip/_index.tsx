import { PrismaClient } from "@prisma/client";
const prisma =  new PrismaClient();
import { db } from "~/db.server";
import { json } from "@remix-run/node";

import { LoaderFunction } from "@remix-run/node";
import {  useLoaderData } from "@remix-run/react";


import type { MetaFunction } from "@remix-run/node";

export const meta: MetaFunction = () => {
  return [
    { title: "MoviePairs" },
    { name: "description", content: "MoviePairs" },
  ];
};

export let loader: LoaderFunction = async ({ request }) => {

  const url = new URL(request.url);
  let a = parseInt(url.searchParams.get("a"))
  console.log("a: ", a)
  const b = parseInt(url.searchParams.get("b"))
  console.log("b: ", b) 

  // get-all-movies BEGIN - WORKS

  const aActorMovies = await prisma.$queryRaw`SELECT movie FROM "assoc" WHERE "assoc"."actor" = ${a}`
  console.log("aActorMovies: ", aActorMovies)
  const aActorMoviesNumArray = aActorMovies.map((r) => r.movie)

  const bActorMovies = await prisma.$queryRaw`SELECT movie FROM "assoc" WHERE "assoc"."actor" = ${b}`
  console.log("bActorMovies: ", bActorMovies)
  const bActorMoviesNumArray = bActorMovies.map((r) => r.movie)

  let inter = aActorMoviesNumArray.filter((num) => bActorMoviesNumArray.includes(num))

  console.log("inter: ", inter)

  const aMovies = await prisma.$queryRaw`SELECT * FROM "movies" WHERE "movies"."myId" =  ANY(${aActorMoviesNumArray})`
  const bMovies = await prisma.$queryRaw`SELECT * FROM "movies" WHERE "movies"."myId" =  ANY(${bActorMoviesNumArray})`



  // get-all-movies END - WORKS


  // get-inter BEGIN - WORKS
  // const act1movies = await prisma.$queryRaw`SELECT * FROM "assoc" JOIN "movies" ON "assoc"."movie" = "movies"."myId" WHERE "assoc"."actor" = 27`
  // const act2movies = await prisma.$queryRaw`SELECT * FROM "assoc" JOIN "movies" ON "assoc"."movie" = "movies"."myId" WHERE "assoc"."actor" = 110`

  // let act1NumsOnly = act1movies.map((r) => r.movie)
  // let act2NumsOnly = act2movies.map((r) => r.movie)
  // let inter = act1NumsOnly.filter((num) => act2NumsOnly.includes(num)) 
  // get-inter END 

  // WORKS
  // const movies = await prisma.$queryRaw`SELECT * FROM movies WHERE "movies"."myId" =  ANY(${inter})`

  // use variable example
  // const result = await prisma.$queryRaw`SELECT * FROM User WHERE email = ${email}`

  // const movies = await prisma.$queryRaw`SELECT * FROM "assoc" JOIN "movies" ON "assoc"."movie" = "movies"."myId" WHERE "assoc"."actor" = 110`
  // return json({ movies, actors, assoc } );


  return json({ aMovies, bMovies, inter } );

} 


export default function Index() {

  let { aMovies, bMovies, inter } = useLoaderData<typeof loader>();


  return (
    <div style={{ fontFamily: "system-ui, sans-serif", lineHeight: "1.8" }}>
      <h1>Welcome to Remix</h1>
      <pre>
      { JSON.stringify(aMovies, null, 2) }
      </pre>


      <ul>
        <li>
          <a
            target="_blank"
            href="https://remix.run/tutorials/blog"
            rel="noreferrer"
          >
            15m Quickstart Blog Tutorial
          </a>
        </li>
        <li>
          <a
            target="_blank"
            href="https://remix.run/tutorials/jokes"
            rel="noreferrer"
          >
            Deep Dive Jokes App Tutorial
          </a>
        </li>
        <li>
          <a target="_blank" href="https://remix.run/docs" rel="noreferrer">
            Remix Docs
          </a>
        </li>
      </ul>
    </div>
  );
}
